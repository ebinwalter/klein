use super::*;

mod ops;
pub use ops::*;

pub struct IntLit {
    pub value: usize,
    pub line: usize,
    pub col: usize
}

impl Ast for IntLit {
    fn unparse(&self, up: &mut Unparser) {
        up.write(&self.value.to_string());
    }

    fn typecheck(&self, _tc: TCCtx) -> Option<TypeNode> {
        Some(TypeNode::Int)
    }
}

impl Expr for IntLit {}

pub struct StringLit {
    pub span: Span,
    pub line: usize,
    pub col: usize,
}

pub struct BoolLit {
    pub value: bool,
    pub line: usize,
    pub col: usize
}

impl Ast for BoolLit {
    fn unparse(&self, up: Up) {
        up.write(if self.value {"true"} else {"false"})
    }

    fn typecheck(&self, _tc: TCCtx) -> Option<TypeNode> {
        Some(TypeNode::Bool)
    }
}
impl Expr for BoolLit {}

impl Ast for StringLit {
    fn unparse(&self, up: Up) {
        up.write_span(self.span);
    }

    fn typecheck(&self, _tc: TCCtx) -> Option<TypeNode> {
        Some(TypeNode::Reference(Rc::new(TypeNode::Char)))
    }

    fn code_location(&self) -> Option<(usize, usize)> {
        Some((self.line, self.col))
    }
}

impl Expr for StringLit {}

pub struct AssignExpr {
    pub loc: BoxLoc,
    pub value: Boxpr,
}

impl Ast for AssignExpr {
    fn unparse(&self, up: &mut Unparser) {
        self.loc.unparse(up);
        up.write(" = ");
        self.value.unparse(up);
    }

    fn analyze_names(&self, na: NACtx) {
        self.loc.analyze_names(na);
        self.value.analyze_names(na);
    }

    fn typecheck(&self, tc: TCCtx) -> Option<TypeNode> {
        let lhs_ty = self.loc.typecheck(tc)?;
        let rhs_ty = self.value.typecheck(tc)?;
        if lhs_ty == rhs_ty {
            Some(rhs_ty)
        } else {
            let m = format!("Assignment of value of type {rhs_ty:?} to variable of type {lhs_ty:?}");
            tc.raise_error(self.value.clone(), m);
            None
        }
    }

    fn code_location(&self) -> Option<(usize, usize)> {
        self.value.code_location()
    }
}

impl Expr for AssignExpr {}

pub struct CallExpr {
    pub fun: BoxLoc,
    pub args: Vec<Boxpr>,
    pub fun_sym: OnceCell<Rc<FuncSymbol>>
}

impl Ast for CallExpr {
    fn unparse(&self, up: Up) {
        self.fun.unparse(up);
        up.write("(");
        let mut first = true;
        for expr in self.args.iter() {
            if !first {
                up.write(", ");
            }
            expr.unparse(up);
            first = false;
        }
        up.write(")");
    }

    fn analyze_names(&self, na: NACtx) {
        self.fun.analyze_names(na);
        for expr in self.args.iter() {
            expr.analyze_names(na);
        }
        if let Some(sym) = self.fun.symbol_rc() {
            let sym = sym.clone();
            if let Symbol::Func(ref f) = *sym {
                self.fun_sym.set(f.clone())
                    .expect("Attempt to re-set symbol for function call");
            } else {
                na.raise_error("Attempt to call non-function".to_owned());
            }
        }
    }

    fn typecheck(&self, tc: TCCtx) -> Option<TypeNode> {
        let fun_arg_types = &self.fun_sym
            .get()
            .expect("Unset fun symbol after name analysis phase")
            .arg_types;
        let n1 = fun_arg_types.len();
        let n2 = self.args.len();
        if n1 != n2 {
            let m = format!("This function takes {n1} arguments, but {n2} were provided");
            tc.raise_error(self.fun.clone(), m);
        } else {
            for (i, e1) in self.args.iter().enumerate() {
                let Some(t1) = e1.typecheck(tc) else { continue };
                let t2 = &fun_arg_types[i];
                let arg_no = i + 1;
                if t1 != *t2 {
                    let m = format!("argument #{arg_no} should be of type {t2}, but a {t1} was given");
                    tc.raise_error(e1.clone(), m);
                }
            }
        }
        Some(self.fun_sym.get().unwrap().return_type.clone())
    }

    fn code_location(&self) -> Option<(usize, usize)> {
        self.fun.code_location()
    }
}

impl Expr for CallExpr {}

pub struct AccessExpr {
    pub obj: Boxpr,
    pub field: IdNode,
    // Populated during typechecker phase
    pub sym: OnceCell<Rc<Symbol>>
}

impl Ast for AccessExpr {
    fn unparse(&self, up: Up) {
        self.obj.unparse(up);
        up.write(".");
        if let Some(_sym) = self.sym.get() {
            up.write("$");
        }
        self.field.unparse(up);
    }

    fn analyze_names(&self, na: NACtx) {
        self.obj.analyze_names(na);
    }

    fn typecheck(&self, tc: TCCtx) -> Option<TypeNode> {
        let obj_ty = self.obj.typecheck(tc);
        if let Some(TypeNode::Struct(s, sym)) = obj_ty {
            let struct_sym = sym.get()
                .unwrap();
            let struct_scope = struct_sym.scope.try_borrow()
                .expect("Failed to borrow scope for struct type");
            let field_string = span_to_str(self.field.span, tc.ref_text);
            if let Some(sym_rc) = struct_scope.get(field_string) {
                let Symbol::Var(ref v) = **sym_rc else {
                    let m = format!(
                        "An entry for {} exists in the struct's definition, \
                        but it is not a member variable",
                        field_string
                    );
                    tc.raise_error(Rc::new(self.field.clone()), m);
                    return None
                };
                let b = (*v.ty).clone();
                self.sym.set(sym_rc.clone()).unwrap();
                return Some(b)
            }
        } else {
            tc.raise_error(self.obj.clone(), "Attempt to access a field of a non-struct".into());
        }
        None
    }

    fn symbol_rc(&self) -> Option<Rc<Symbol>> {
        self.sym.get().cloned()
    }

    fn symbol(&self) -> Option<&Symbol> {
        self.sym.get().map(Borrow::borrow)
    }

    fn code_location(&self) -> Option<(usize, usize)> {
        self.field.code_location()
    }
}

impl Expr for AccessExpr {}

impl Loc for AccessExpr {}

pub struct AddrExpr {
    pub expr: Boxpr,
}

impl Ast for AddrExpr {
    fn unparse(&self, up: Up) {
        up.write("&");
        self.expr.unparse(up);
    }

    fn analyze_names(&self, na: NACtx) {
        self.expr.analyze_names(na);
    }

    fn code_location(&self) -> Option<(usize, usize)> {
        self.expr.code_location()
    }

    fn typecheck(&self, tc: TCCtx) -> Option<TypeNode> {
        let inner_ty = self.expr.typecheck(tc)?;
        Some(TypeNode::Reference(Rc::new(inner_ty)))
    }
}

impl Expr for AddrExpr {}

pub struct DerefExpr {
    pub ptr: Boxpr,
    deref_sym: OnceCell<Rc<StructDeclSymbol>>
}

impl DerefExpr {
    pub fn new(expr: Boxpr) -> Rc<Self> {
        Rc::new(DerefExpr {
            ptr: expr,
            deref_sym: OnceCell::new()
        })
    }
}

impl Ast for DerefExpr {
    fn unparse(&self, up: Up) {
        up.write("(*");
        self.ptr.unparse(up);
        up.write(")")
    }

    fn analyze_names(&self, na: NACtx) {
        self.ptr.analyze_names(na);
    }

    fn code_location(&self) -> Option<(usize, usize)> {
        self.ptr.code_location()
    }

    fn typecheck(&self, tc: TCCtx) -> Option<TypeNode> {
        let inner_ty = self.ptr.typecheck(tc)?;
        if let TypeNode::Reference(pointee) = inner_ty {
            Some((*pointee).clone())
        } else {
            tc.raise_error(self.ptr.clone(), "Attempt to dereference a non-pointer".into());
            None
        }
    }
}

impl Expr for DerefExpr {}

pub struct IndexExpr {
    pub ptr: Boxpr,
    pub index: Boxpr
}

impl Ast for IndexExpr {
    fn unparse(&self, up: Up) {
        self.ptr.unparse(up);
        up.write("[");
        self.index.unparse(up);
        up.write("]");
    }

    fn analyze_names(&self, na: NACtx) {
        self.ptr.analyze_names(na);
        self.index.analyze_names(na);
    }

    fn typecheck(&self, tc: TCCtx) -> Option<TypeNode> {
        let ptr_ty = self.ptr.typecheck(tc)?;
        let index_ty = self.index.typecheck(tc)?;
        if let TypeNode::Reference(r) = ptr_ty {
            if index_ty != TypeNode::Int {
                tc.raise_error(
                    self.index.clone(),
                    "Indices of an array or pointer must be integers".into()
                );
            }
            Some((*r).clone())
        } else {
            tc.raise_error(self.ptr.clone(), "Only pointers and arrays can be indexed".into());
            None
        }
    }
}

impl Expr for IndexExpr {}
