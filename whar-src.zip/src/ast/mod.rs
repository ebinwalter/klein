use std::fmt::Display;
use std::io::stdout;
use std::rc::Rc;
use std::fmt::Write;
use std::cell::{Cell, OnceCell, RefCell};
use std::borrow::{Borrow, BorrowMut};
use crate::symbols::*;

use lrpar::Span;

mod decls;
mod exprs;
mod stmts;

pub use decls::*;
pub use exprs::*;
pub use stmts::*;

// We define this type alias because 99% of the time we
// aren't going to care about the lifetimes involved here.
// It makes implementing the AST trait a fair bit more
// concise.
type Up<'a, 'b> = &'a mut Unparser<'b>;

pub struct Unparser<'a> {
    out: Box<dyn std::io::Write>,
    ref_text: &'a [u8],
    indent: usize,
}

impl<'a> Unparser<'a> {
    fn new_stdout(ref_text: &'a str) -> Self {
        Unparser {
            out: Box::new(stdout()),
            indent: 0,
            ref_text: ref_text.as_bytes(),
        }
    }

    fn write(&mut self, s: &str) {
        let _ = self.out.write(s.as_bytes());
    }

    fn space(&mut self) {
        let _ = self.out.write(" ".as_bytes());
    }

    fn new_line(&mut self) {
        let _ = self.out.write("\n".as_bytes());
    }

    fn end_stmt(&mut self) {
        let _ = self.out.write(";\n".as_bytes());
    }

    fn write_span(&mut self, s: Span) {
        let to_write = &self.ref_text[s.start()..s.end()];
        let _ = self.out.write(to_write);
    }

    fn write_indent(&mut self) {
        for _ in 0..self.indent {
            let _ = self.out.write("  ".as_bytes());
        }
    }

    fn indent(&mut self) {
        self.indent += 1;
    }

    fn outdent(&mut self) {
        self.indent = self.indent.saturating_sub(1);
    }
}

pub struct NameAnalysisContext<'a> {
    ref_text: &'a str,
    sym_tab: SymbolTable,
    err_msgs: Vec<String>,
    offset_stack: Vec<u32>,
}

impl<'a> NameAnalysisContext<'a> {
    fn str_for_id(&self, id: &IdNode) -> &str {
        unsafe {
            self.ref_text.get_unchecked(id.span.start()..id.span.end())
        }
    }
    fn start_frame(&mut self) {
        self.offset_stack.push(4);
    }
    fn end_frame(&mut self) {
        self.offset_stack.pop();
    }
    fn start_branch(&mut self) {
        self.offset_stack.push(*self.offset_stack.last().unwrap());
    }
    fn end_branch(&mut self) {
        self.offset_stack.pop();
    }
    fn add_offset(&mut self, size: u32) -> u32 {
        let last = self.offset_stack.last_mut().unwrap();
        let old = *last;
        *last += size;
        old
    }
    fn string_for_id(&self, id: &IdNode) -> String {
        unsafe {
            self.ref_text.get_unchecked(id.span.start()..id.span.end()).to_owned()
        }
    }
    fn define_or_err(&mut self, id: &IdNode, sym: Symbol) {
        let name = self.string_for_id(id); 
        if let Err(SymTabError::Exists) = self.sym_tab.define(name.to_owned(), sym) {
            self.err_msgs.push(format!("Multiple declaration of identifier {name}"));
        }
    }
    fn lookup_or_err(&mut self, id: &IdNode) -> Option<Rc<Symbol>> {
        let name = self.str_for_id(id);
        match self.sym_tab.lookup_global(name) {
            Ok(sym) => Some(sym),
            Err(SymTabError::DoesntExist) => {
                self.err_msgs.push(format!("Undefined identifier {} at line {}, col {}", name, id.line, id.col));
                None
            }
            Err(_) => {
                self.err_msgs.push(
                format!("Empty symbol table encountered while looking up name '{}'",
                    name));
                None
            }
        }
    }
    fn lookup(&mut self, id: &IdNode) -> Option<Rc<Symbol>> {
        let name = self.str_for_id(id);
        match self.sym_tab.lookup_global(name) {
            Ok(sym) => Some(sym),
            Err(SymTabError::DoesntExist) => None,
            Err(_) => {
                panic!("Empty symbol table encountered while looking up name '{}'", name);
            }
        }
    }
    fn raise_error(&mut self, string: String) {
        self.err_msgs.push(string);
    }
}

type NACtx<'a, 'b> = &'a mut NameAnalysisContext<'b>;

struct TypeCheckingContext<'a> {
    err_msgs: Vec<String>,
    ref_text: &'a str,
}

type TCCtx<'a, 'b> = &'a mut TypeCheckingContext<'b>;

impl TypeCheckingContext<'_> {
    fn raise_error(&mut self, at: Rc<dyn Ast>,  string: String) {
        let (line, col) = at.code_location().unwrap_or((0, 0));
        let m = format!(
            "At line {line}, col {col}: {string}"
        );
        self.err_msgs.push(m);
    }
}

trait Ast {
    fn unparse(&self, up: Up);
    fn analyze_names(&self, na: NACtx) {}
    fn typecheck(&self, tc: TCCtx) -> Option<TypeNode> { None }
    /// Return a canonical symbol associated with this AST node.
    /// For example, if this is an ID, give the VarDecl symbol associated with
    /// its definition; if this is an AST node for a `struct X` type, give the StructDeclSymbol
    /// associated with that struct.
    ///
    /// If there is a OnceCell<Rc<Symbol>> in the struct, it can be returned with
    /// self.cell.get().cloned().
    fn symbol(&self) -> Option<&Symbol> {
        None
    }
    fn symbol_rc(&self) -> Option<Rc<Symbol>> {
        None
    }
    fn code_location(&self) -> Option<(usize, usize)> {
        None
    } 
}

// I had a hard time deciding what type Boxpr should actually be.
// Initially, I chose Box<dyn Expr>, but I realized this would prevent me
// from referencing AST constructs in the symbol table.
// I then realized I might want to put references back into the symbol table alongside the
// AST data to reduce my indirection at later phases, so I thought to make it an
// Rc<RefCell<dyn Expr>>.  But this is a code smell of sorts, so I decided to simply use
// Rc<dyn Expr> and give anything which needs an update a OnceCell field.

/// Things that can be evaluated.
pub trait Expr: Ast {}
pub type Boxpr = Rc<dyn Expr>;

/// Things that posit something to be used or acted on.
pub trait Decl: Ast {
    fn split_decl(&self) -> Option<(Rc<dyn Decl>, Rc<dyn Stmt>)> {
        None
    }
}
pub type BoxDecl = Rc<dyn Decl>;

/// Things that can be sequenced.
pub trait Stmt: Ast {}
pub type BoxStmt = Rc<dyn Stmt>;

/// Things associated with an address.
pub trait Loc: Expr { }
pub type BoxLoc = Rc<dyn Loc>;

pub struct Program {
    pub decls: Vec<BoxDecl>,
}

pub enum DeclOrStmt {
    Decl(BoxDecl),
    Stmt(BoxStmt),
}

impl Ast for DeclOrStmt {
    fn unparse(&self, up: Up) {
        match self {
            DeclOrStmt::Decl(d) => d.unparse(up),
            DeclOrStmt::Stmt(s) => s.unparse(up),
        }
    }

    fn analyze_names(&self, na: NACtx) {
        match self {
            DeclOrStmt::Decl(d) => (d.clone() as Rc<dyn Ast>).analyze_names(na),
            DeclOrStmt::Stmt(s) => (s.clone() as Rc<dyn Ast>).analyze_names(na),
        }
    }

    fn typecheck(&self, tc: TCCtx) -> Option<TypeNode> {
        match self {
            DeclOrStmt::Decl(d) => d.clone().typecheck(tc),
            DeclOrStmt::Stmt(s) => s.clone().typecheck(tc),
        };
        None
    }
}

impl Program {
    pub fn print(&self, txt: &str) {
        let mut up = Unparser::new_stdout(txt);
        self.unparse(&mut up);
    }

    pub fn name_analysis(&self, txt: &str) -> bool {
        let mut na = NameAnalysisContext {
            ref_text: txt,
            err_msgs: Vec::new(),
            sym_tab: SymbolTable::new(),
            offset_stack: Vec::new(),
        };
        self.analyze_names(&mut na);
        for err in na.err_msgs.iter() {
            eprintln!("{}", err)
        }
        na.err_msgs.is_empty()
    }

    pub fn type_checking(&self, txt: &str) -> bool {
        let mut tc = TypeCheckingContext {
            ref_text: txt,
            err_msgs: Vec::new(),
        };
        self.typecheck(&mut tc);
        for err in tc.err_msgs.iter() {
            eprintln!("{}", err)
        }
        tc.err_msgs.is_empty()
    }
}

impl Ast for Program {
    fn unparse(&self, unparser: Up) {
        for decl in self.decls.iter() {
            decl.unparse(unparser);
        }
    }
    
    fn analyze_names(&self, na: NACtx) {
        for decl in self.decls.iter() {
            decl.analyze_names(na);
        }
    }

    fn typecheck(&self, tc: TCCtx) -> Option<TypeNode> {
        for decl in self.decls.iter() {
            decl.typecheck(tc);
        }
        None
    }
}

pub struct ScopeBlock {
    pub list: RefCell<Vec<DeclOrStmt>>,
    pub table: OnceCell<TableLayer>
}

impl Ast for ScopeBlock {
    fn unparse(&self, up: Up) {
        up.write("{");
        up.new_line();
        up.indent();
        self.get_list().iter().for_each(|x| x.unparse(up));
        up.outdent();
        up.write_indent();
        up.write("}");
    }

    fn analyze_names(&self, na: NACtx) {
        na.sym_tab.push_scope();
        na.start_branch();
        self.list.try_borrow().unwrap()
            .iter().for_each(|x| x.analyze_names(na));
        self.table.set(na.sym_tab.pop_scope().unwrap()).expect("Table already set for this scope block");
        na.end_branch();
    }

    fn typecheck(&self, tc: TCCtx) -> Option<TypeNode> {
        self.list.try_borrow().unwrap().iter().for_each(|x| { x.typecheck(tc); });
        self.lift_decls();
        None
    }
}

impl ScopeBlock {
    pub fn lift_decls(&self) {
        let mut stmt_list = Vec::new();
        let mut decl_list = Vec::new();
        for item in self.list.try_borrow().unwrap().iter() {
            match item {
                DeclOrStmt::Stmt(stmt) => stmt_list.push(stmt.clone()),
                DeclOrStmt::Decl(decl) => {
                    if let Some((decl, stmt)) = decl.split_decl() {
                        decl_list.push(decl);
                        stmt_list.push(stmt);
                   } else {
                        decl_list.push(decl.clone());
                    }
                }
            }
        }
        let new_list = decl_list.into_iter().map(DeclOrStmt::Decl)
            .chain(stmt_list.into_iter().map(DeclOrStmt::Stmt))
            .collect();
        *self.list.try_borrow_mut().unwrap() = new_list;
    }

    pub fn get_list(&self) -> std::cell::Ref<Vec<DeclOrStmt>> {
        self.list.try_borrow().unwrap()
    } 
}

#[derive(Debug, Clone)]
pub enum TypeNode {
    Struct(IdNode, OnceCell<Rc<StructDeclSymbol>>),
    Bool,
    Int,
    Char,
    Double,
    Void,
    SelfRef,
    Reference(Rc<TypeNode>),
}

impl TypeNode {
    fn size(&self) -> u32 {
        match self {
            Self::Struct(_, decl) => {
                decl.get().unwrap().size
            }
            Self::Bool => 4,
            Self::Int => 4,
            Self::Char => 1,
            Self::Double => 8,
            Self::Void => 4,
            Self::Reference(_) => 4,
            _ => todo!()
        }
    }
}

impl Display for TypeNode {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Struct(id, _sym) => {
                let s = format!(
                    "struct {}", id.symbol().unwrap().string_id()
                );
                f.write_str(&s)
            },
            Self::Bool => f.write_str("bool"),
            Self::Int => f.write_str("int"),
            Self::Char => f.write_str("char"),
            Self::Double => f.write_str("double"),
            Self::Void => f.write_str("void"),
            Self::Reference(t) => {
                t.fmt(f).and_then(|_| f.write_char('*'))
            }
            _ => todo!()
        }
    }
}

impl PartialEq for TypeNode {
    fn eq(&self, other: &Self) -> bool {
        match self {
            TypeNode::Struct(_this_id, this_cell) => {
                if let TypeNode::Struct(_other_id, other_cell) = other {
                    Rc::ptr_eq(this_cell.get().unwrap(), other_cell.get().unwrap())
                } else {
                    false
                }
            },
            TypeNode::Int => matches!(other, TypeNode::Int),
            TypeNode::Bool => matches!(other, TypeNode::Bool),
            TypeNode::Char => matches!(other, TypeNode::Char),
            TypeNode::Double => matches!(other, TypeNode::Double),
            TypeNode::Void => matches!(other, TypeNode::Void),
            TypeNode::SelfRef => todo!(),
            TypeNode::Reference(self_inner) => {
                if let TypeNode::Void = **self_inner {
                     true
                } else if let TypeNode::Reference(other_inner) = other {
                    self_inner == other_inner
                } else {
                    false
                }
            }
        }
    }
}

impl Ast for TypeNode {
    fn unparse(&self, up: Up) {
        match self {
            TypeNode::Struct(id, _) => {
                up.write("struct ");
                id.unparse(up);
            }
            TypeNode::Bool => up.write("bool"),
            TypeNode::Int => up.write("int"),
            TypeNode::Double => up.write("double"),
            TypeNode::Char => up.write("char"),
            TypeNode::SelfRef => up.write("self"),
            TypeNode::Void => up.write("void"),
            TypeNode::Reference(ty) => {
                ty.unparse(up);
                up.write("*");
            }
        }
    }

    fn analyze_names(&self, na: NACtx) {
        use TypeNode::*;
        match self {
            Void => (),
            TypeNode::Struct(id, cell) => {
                if let Some(s) = na.lookup(id) {
                    if let Symbol::Struct(ref rcs) = *s {
                        cell.set(rcs.clone()).unwrap();
                    } else {
                        na.raise_error(
                            format!("Usage of non-struct symbol {} in a struct type at line {}, column {}", 
                                na.string_for_id(id), id.line, id.col));
                    }
                } else {
                    let err = format!(
                        "Usage of undefined symbol {} in a struct type at line {}, column {}",
                        na.string_for_id(id), id.line, id.col
                    );
                    na.raise_error(err);
                }
            },
            TypeNode::Reference(ty) => {
                ty.analyze_names(na);
            }
            TypeNode::Int | TypeNode::Bool | TypeNode::Char
                | TypeNode::Double => (),
            _ => todo!(),
        }
    }
}

pub struct IdNode {
    pub span: Span,
    pub sym: OnceCell<Rc<Symbol>>,
    pub line: usize,
    pub col: usize,
}

impl Clone for IdNode {
    fn clone(&self) -> Self {
        let cell = OnceCell::new();
        if let Some(v) = self.sym.get() {
            cell.set(v.clone()).unwrap();
        }
        Self {
            span: self.span,
            sym: cell,
            line: self.line,
            col: self.col
        }
    }
}

impl std::fmt::Debug for IdNode {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(&format!("Identifier at line {}, col {}", self.line, self.col))
    }
}

fn span_to_str<'a>(ref s: Span, str: &'a str) -> &'a str {
    unsafe {
        str.get_unchecked(s.start()..s.end())
    }
}

impl Ast for IdNode {
    fn unparse(&self, up: Up) {
        if let Some(_) = self.sym.get() {
            up.write("$");
        }
        up.write_span(self.span);
    }

    fn analyze_names(&self, na: NACtx) {
        if let Some(sym) = na.lookup_or_err(self) {
            self.sym.set(sym)
                .expect("Attempt to set IdNode's sym for the second time -- has name analysis been run more than once?");
        }
    }

    fn symbol(&self) -> Option<&Symbol> {
        self.sym.get().map(Borrow::borrow)
    }

    fn symbol_rc(&self) -> Option<Rc<Symbol>> {
        self.sym.get().cloned()
    }

    fn typecheck(&self, tc: TCCtx) -> Option<TypeNode> {
        if let Symbol::Var(vs) = &**self.sym.get().unwrap() {
            Some((*vs.ty).clone())
        } else {
            tc.raise_error(Rc::new(self.clone()), "Attempted to check the type of a non-variable".into());
            None
        }
    }

    fn code_location(&self) -> Option<(usize, usize)> {
        Some((self.line, self.col))
    }
}

impl Loc for IdNode {}

impl Expr for IdNode {}

pub struct FormalParam { 
    pub ty: TypeNode,
    pub id: IdNode,
}

impl Ast for FormalParam {
    fn unparse(&self, up: Up) {
        if let TypeNode::SelfRef = self.ty {
            up.write("self");
        } else {
            self.ty.unparse(up);
            up.write(" ");
            self.id.unparse(up);
        }
    }

    fn analyze_names(&self, na: NACtx) {
        let sym = VarSymbol {
            id: na.string_for_id(&self.id),
            ty: Rc::new(self.ty.clone()),
            offset: 0,
        };
        na.define_or_err(&self.id, Symbol::Var(sym.into()));
    }
}

pub struct FormalsList {
    pub list: Vec<FormalParam>,
}

impl Ast for FormalsList {
    fn unparse(&self, up: Up) {
        let mut it = self.list.iter();
        it.next().inspect(|x| x.unparse(up));
        let () = it.map(|x| {
            up.write(", ");
            x.unparse(up);
        }).collect();
    }
}
