use super::*;

pub struct StructDecl {
    pub id: IdNode,
    pub decls: Vec<BoxDecl>,
    pub scope: OnceCell<TableLayer>
}

impl Ast for StructDecl {
    fn unparse(&self, up: Up) {
        up.write("struct ");
        self.id.unparse(up);
        up.write(" {");
        up.new_line();
        up.indent();
        for decl in self.decls.iter() {
            decl.unparse(up);
        }
        up.outdent();
        up.write_indent();
        up.write("}");
        up.new_line();
    }

    fn analyze_names(&self, na: NACtx) {
        let name = na.string_for_id(&self.id);
        let decl_scope = SymbolTable::new_layer();
        let decl_sym = Rc::new(StructDeclSymbol {
            id: name,
            scope: decl_scope.clone(),
            size: OnceCell::new(),
        });
        na.define_or_err(&self.id, Symbol::Struct(decl_sym.clone()));
        na.sym_tab.push_this_scope(decl_scope);
        let mut offset = 0;
        for decl in self.decls.iter() {
            decl.analyze_names(na);
            let Some(sym) = decl.symbol() else { continue };
            let Symbol::Var(ref vs) = *sym else { continue };
            let size = vs.ty.size() as u32;
            vs.offset.set(offset as i32).unwrap();
            offset += size;
        }
        decl_sym.size.set(offset).unwrap();
        let scope = na.sym_tab.pop_scope()
            .expect("Extra pop_scope occurred during name analysis inside struct");
        self.scope.set(scope.clone())
            .unwrap();
    }
}

impl Decl for StructDecl {}

pub struct VarDecl {
    pub ty: TypeNode,
    pub id: IdNode,
    pub init: Option<Boxpr>,
    pub offset: OnceCell<i32>
}

impl Decl for VarDecl {
    fn split_decl(&self) -> Option<(Rc<dyn Decl>, Rc<dyn Stmt>)> {
        if let Some(ref init) = self.init {
            let decl = VarDecl {
                ty: self.ty.clone(),
                id: self.id.clone(),
                init: None
            };
            let assignment = AssignExpr {
                loc: Rc::new(self.id.clone()),
                value: init.clone()
            };
            let stmt = ExprStmt { expr: Rc::new(assignment) };
            Some((Rc::new(decl), Rc::new(stmt)))
        } else {
            None
        }
    }
}

impl Ast for VarDecl {
    fn unparse(&self, up: Up) {
        up.write_indent();
        self.ty.unparse(up);
        up.write(" ");
        self.id.unparse(up);
        if let Some(ref e) = self.init {
            up.write(" = ");
            e.unparse(up);
        }
        up.write(";");
        up.new_line();
    }
    
    fn analyze_names(&self, na: NACtx) {
        // Analyze this beforehand because we don't want the init value to
        // reference the variable we are defining
        self.ty.analyze_names(na);
        if let Some(ref init) = self.init {
            init.analyze_names(na);
        }
        let name = span_to_str(self.id.span, na.ref_text);
        let sym = VarSymbol {
            id: name.to_owned(),
            ty: Rc::new(self.ty.clone()),
            offset: 0,
        };
        if let Ok(_existing) = na.sym_tab.lookup_local(name) {
            todo!("Raise duplicate identifier error");
        }
        na.sym_tab.define(name.to_owned(), Symbol::Var(sym.into())).unwrap();
    }

    fn typecheck(&self, tc: TCCtx) -> Option<TypeNode> {
        if let Some(init) = &self.init {
            let t = init.typecheck(tc)?;
            let expected = self.ty.clone();
            if t != expected {
                let m = format!("Attempt to initialize a variable of type {expected} with a value of type {t}");
                tc.raise_error(init.clone(), m);
            }
        }
        None
    }
}

pub struct FunDecl { 
    pub id: IdNode,
    pub ret_ty: TypeNode,
    pub formals: FormalsList,
    pub body: Option<ScopeBlock>,
}

impl Decl for FunDecl { }

impl Ast for FunDecl {
    fn unparse(&self, up: Up) {
        up.write_indent();
        up.write("fun ");
        self.id.unparse(up);
        up.write("(");
        self.formals.unparse(up);
        up.write(") -> ");
        self.ret_ty.unparse(up);
        if let Some(body) = &self.body {
            up.space();
            body.unparse(up)
        } else {
            up.write(";");
        }
        up.new_line();
    }

    fn analyze_names(&self, na: NACtx) {
        let name = span_to_str(self.id.span, na.ref_text);
        self.ret_ty.analyze_names(na);
        let layer = na.sym_tab.push_scope();
        let my_fun_sym = Rc::new(FuncSymbol {
            has_body: self.body.is_some(),
            id: name.to_owned(),
            arg_types: self.formals.list.iter().map(|x| x.ty.clone()).collect(),
            return_type: self.ret_ty.clone(),
            scope: layer,
        });
        na.define_or_err(&self.id, Symbol::Func(my_fun_sym.clone()));
        let mut formal_offset = -8;
        for formal in self.formals.list.iter() {
            let formal_name = span_to_str(formal.id.span, na.ref_text);
            let formal_sym = VarSymbol {
                id: formal_name.to_owned(),
                ty: Rc::new(formal.ty.clone()),
                offset: formal_offset,
            };
            na.define_or_err(&formal.id, Symbol::Var(Rc::new(formal_sym)));
            formal_offset -= 4;
        }
        na.start_frame();
        if let Some(ref body) = self.body {
            for item in body.get_list().iter() {
                item.analyze_names(na);
            }
        }
        na.end_frame();
        na.sym_tab.pop_scope().unwrap();
        na.sym_tab.define(name.to_owned(), Symbol::Func(my_fun_sym.clone())).unwrap();
    }
    
    fn typecheck(&self, tc: TCCtx) -> Option<TypeNode> {
        if let Some(b) = &self.body {
            b.typecheck(tc);
            b.lift_decls();
        }
        None
    }
}
