use std::{env::args, process::exit};

use lrlex::lrlex_mod;
use lrpar::lrpar_mod;

mod ast;
mod symbols;
lrlex_mod!("whar.l");
lrpar_mod!("whar.y");

fn main() {
    let Some(filename) = args().nth(1) else {
        println!("Usage: wharc <file>");
        exit(1);
    };
    let file = std::fs::read_to_string(filename).unwrap(); 
    let lexerdef = whar_l::lexerdef();
    let lexer = lexerdef.lexer(&file);
    let (res, errs) = whar_y::parse(&lexer);
    for e in errs {
        println!("{}", e.pp(&lexer, &whar_y::token_epp));
    }
    match res {
        Some(Ok(program)) => {
            if !program.name_analysis(&file) {
                println!("Processing failed during name analysis");
            } else if !program.type_checking(&file) {
                println!("Processing failed during type checking");
            } else {
                program.print(&file);
            }
        } 
        _ => eprintln!("Unable to parse program"),
    }
}
